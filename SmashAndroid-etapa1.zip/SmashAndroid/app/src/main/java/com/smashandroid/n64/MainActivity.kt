package com.smashandroid.n64

import android.app.Activity
import android.database.Cursor
import android.provider.OpenableColumns
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {

    private lateinit var statusText: TextView

    private val romPicker =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) {
                importRom(uri)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
            setBackgroundColor(0xFF10131C.toInt())
        }

        val title = TextView(this).apply {
            text = "SMASH ANDROID"
            textSize = 30f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }

        val subtitle = TextView(this).apply {
            text = "Emulador N64 · Proyecto personal"
            textSize = 15f
            setTextColor(0xFFB8C2D8.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 28)
        }

        val chooseButton = Button(this).apply {
            text = "Seleccionar ROM"
            setOnClickListener {
                romPicker.launch(arrayOf("*/*"))
            }
        }

        statusText = TextView(this).apply {
            text = "Estado: listo. Selecciona un archivo de juego para importarlo."
            textSize = 14f
            setTextColor(0xFFE0E6F2.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 12)
        }

        val nativeStatus = TextView(this).apply {
            text = "Motor nativo: ${nativeStatus()}"
            textSize = 12f
            setTextColor(0xFF91A0B8.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 0)
        }

        root.addView(title, matchWrap())
        root.addView(subtitle, matchWrap())
        root.addView(chooseButton, matchWrap())
        root.addView(statusText, matchWrap())
        root.addView(nativeStatus, matchWrap())

        setContentView(root)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun importRom(uri: Uri) {
        statusText.text = "Importando archivo…"
        try {
            val romDir = File(filesDir, "roms").apply { mkdirs() }
            val destination = File(romDir, "selected_game${guessExtension(uri)}")
            contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "No se pudo abrir el archivo seleccionado." }
                FileOutputStream(destination).use { output ->
                    input.copyTo(output)
                }
            }
            statusText.text = "Archivo importado: ${destination.name}\nTamaño: ${destination.length()} bytes\nLa emulación se añadirá en la siguiente etapa."
        } catch (error: Exception) {
            statusText.text = "No se pudo importar el archivo: ${error.localizedMessage}"
        }
    }

    private fun guessExtension(uri: Uri): String {
        var displayName = ""
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index >= 0) displayName = cursor.getString(index).orEmpty()
            }
        }
        val extension = displayName.substringAfterLast('.', "").takeIf { it.length in 1..8 }
        return extension?.let { ".$it" } ?: ".rom"
    }

    private external fun nativeStatus(): String

    companion object {
        init {
            System.loadLibrary("smash_native")
        }
    }
}
