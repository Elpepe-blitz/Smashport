#include <jni.h>

extern "C"
JNIEXPORT jstring JNICALL
Java_com_smashandroid_n64_MainActivity_nativeStatus(JNIEnv* env, jobject /* thiz */) {
    return env->NewStringUTF("JNI/C++ conectado");
}
